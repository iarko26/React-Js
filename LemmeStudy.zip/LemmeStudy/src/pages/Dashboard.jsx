import React from 'react'

function Dashboard() {
  return (
    <div className='flex justify-center items-center'>
      Welcome to LemmeStudy Dashboard
    </div>
  )
}

export default Dashboard
