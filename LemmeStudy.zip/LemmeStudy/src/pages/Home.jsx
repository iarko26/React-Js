import React from 'react'

function Home() {
  return (
    <div className='flex justify-center items-center text-white h-full text-3xl'>
      Welcome to LemmeStudy
    </div>
  )
}

export default Home
